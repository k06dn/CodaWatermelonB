import { PhoneMockup } from "./components/PhoneMockup";
import { CodaApp } from "./components/CodaApp";

export default function App() {
  return (
    <PhoneMockup>
      <CodaApp />
    </PhoneMockup>
  );
}
