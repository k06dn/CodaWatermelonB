"use client";

import { useState } from "react";
import { Mic, Users, Bell, MessageSquare, BookOpen, Map } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { EnvironmentRadar } from "./EnvironmentRadar";
import { TalkView } from "./TalkView";
import { SensoryScoutView } from "./SensoryScoutView";
import { StudyView } from "./StudyView";
import { AlertsView } from "./AlertsView";

type View = "aware" | "conversation" | "scout" | "study" | "alerts";

interface AwareScreenProps {
  userName?: string;
  onOpenSettings?: () => void;
  onViewChange?: (view: View) => void;
}

export function AwareScreen({ userName = "there", onOpenSettings, onViewChange }: AwareScreenProps) {
  const [currentView, setCurrentView] = useState<View>("aware");

  const handleViewChange = (view: View) => {
    setCurrentView(view);
    onViewChange?.(view);
  };

  const navItems = [
    { id: "aware" as View, icon: Mic, label: "Aware", color: "from-[#6B5CAC] to-[#8B7BC8]" },
    { id: "conversation" as View, icon: MessageSquare, label: "Talk", color: "from-[#FF85A2] to-[#FFB3C6]" },
    { id: "scout" as View, icon: Map, label: "Scout", color: "from-[#10B981] to-[#34D399]" },
    { id: "study" as View, icon: BookOpen, label: "Study", color: "from-[#F59E0B] to-[#FBBF24]" },
    { id: "alerts" as View, icon: Bell, label: "Alerts", color: "from-[#3B82F6] to-[#60A5FA]" },
  ];

  return (
    <div className="h-full bg-[#FFFBF5] relative overflow-hidden">
      {/* Decorative background blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
        <div className="absolute top-20 -left-20 w-80 h-80 bg-[#10B981]/15 rounded-full blur-3xl"></div>
        <div className="absolute bottom-32 -right-20 w-80 h-80 bg-[#FFB3C6]/20 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#6B5CAC]/10 rounded-full blur-3xl"></div>
      </div>

      {/* Main content area */}
      <div className="relative h-full pb-28">
        <AnimatePresence mode="wait">
          {currentView === "aware" && (
            <motion.div
              key="aware"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              <EnvironmentRadar userName={userName} />
            </motion.div>
          )}
          {currentView === "conversation" && (
            <motion.div
              key="conversation"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              <TalkView userName={userName} />
            </motion.div>
          )}
          {currentView === "scout" && (
            <motion.div
              key="scout"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              <SensoryScoutView />
            </motion.div>
          )}
          {currentView === "study" && (
            <motion.div
              key="study"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              <StudyView />
            </motion.div>
          )}
          {currentView === "alerts" && (
            <motion.div
              key="alerts"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="h-full"
            >
              <AlertsView />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom navigation - glassmorphic */}
      <div className="absolute bottom-0 left-0 right-0 bg-white/60 backdrop-blur-xl border-t border-[#2A0098]/10">
        <div className="grid grid-cols-5 px-2 py-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => handleViewChange(item.id)}
                className="flex flex-col items-center gap-1.5 py-2 relative focus:outline-none rounded-xl"
                aria-label={`${item.label} tab${isActive ? ', currently selected' : ''}`}
                aria-current={isActive ? 'page' : undefined}
              >
                <motion.div
                  className={`p-2.5 rounded-full ${isActive ? `bg-gradient-to-br ${item.color} shadow-lg` : 'bg-white/50 backdrop-blur-sm'}`}
                  animate={{ scale: isActive ? 1.1 : 1 }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                  aria-hidden="true"
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-[#6B5CAC]'}`} strokeWidth={2.5} />
                </motion.div>
                <span className={`text-xs ${isActive ? 'text-[#2A0098]' : 'text-[#6B5CAC]'}`} style={{ fontFamily: 'var(--font-sans)' }}>
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}