import { motion } from "motion/react";
import { LucideIcon } from "lucide-react";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export function EmptyState({ icon: Icon, title, description, action }: EmptyStateProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-12 px-6 text-center"
    >
      <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#FF85A2]/20 to-[#FFB3C6]/20 backdrop-blur-sm flex items-center justify-center mb-4" aria-hidden="true">
        <Icon className="w-10 h-10 text-[#FF85A2]" strokeWidth={1.5} aria-hidden="true" />
      </div>
      <h3 className="text-[#2A0098] mb-2">{title}</h3>
      <p className="text-[#6B5CAC] text-sm max-w-xs mb-6">{description}</p>
      {action && (
        <button
          onClick={action.onClick}
          className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#FF85A2] to-[#FFB3C6] text-white text-sm leading-none shadow-md hover:shadow-lg hover:scale-105 focus:outline-none focus:ring-2 focus:ring-[#2A0098] focus:ring-offset-2 focus:ring-offset-[#FFFBF5] transition-all active:scale-95"
        >
          {action.label}
        </button>
      )}
    </motion.div>
  );
}
