"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Radar, MessageCircle, Users, Bell, BookOpen, Settings } from "lucide-react";
import { AwareScreen } from "./AwareScreen";
import { TalkView } from "./TalkView";
import { CommunityView } from "./CommunityView";
import { AlertsView } from "./AlertsView";
import { StudyView } from "./StudyView";
import { WaveLoader } from "./WaveLoader";
import { SettingsView } from "./SettingsView";
import { OfflineIndicator } from "./OfflineIndicator";
import { OnboardingFlow, type OnboardingData } from "./OnboardingFlow";
import { Toaster } from "./ui/sonner";
import { toast } from "sonner@2.0.3";

export type AppView = "aware" | "talk" | "connect" | "study" | "alerts" | "settings";

interface NavItem {
  id: AppView;
  icon: React.ComponentType<{ className?: string; strokeWidth?: number; "aria-hidden"?: boolean }>;
  label: string;
}

export function CodaApp() {
  const [isLoading, setIsLoading] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [activeView, setActiveView] = useState<AppView>("aware");
  const [currentSubView, setCurrentSubView] = useState<"aware" | "conversation" | "scout" | "study" | "alerts">("aware");
  const [userName, setUserName] = useState<string>("there");

  // Initialize theme system and check onboarding
  useEffect(() => {
    // Load and apply dyslexia settings (theme, spacing, fonts) immediately
    const savedSettings = localStorage.getItem("coda-dyslexia-settings");
    if (savedSettings) {
      try {
        const settings = JSON.parse(savedSettings);
        const root = document.documentElement;
        
        // Apply saved theme
        if (settings.colorTheme) {
          root.setAttribute("data-color-theme", settings.colorTheme);
        }
        
        // Apply dyslexia settings
        if (settings.lineSpacing) {
          root.style.setProperty("--dyslexia-line-spacing", `${settings.lineSpacing[0] / 100}`);
        }
        if (settings.letterSpacing) {
          root.style.setProperty("--dyslexia-letter-spacing", `${settings.letterSpacing[0] / 10}px`);
        }
        if (settings.wordSpacing) {
          root.style.setProperty("--dyslexia-word-spacing", `${settings.wordSpacing[0] / 10}px`);
        }
        if (settings.textSize) {
          root.style.setProperty("--dyslexia-text-size", `${settings.textSize[0] / 100}`);
        }
        if (settings.paragraphSpacing) {
          root.style.setProperty("--dyslexia-paragraph-spacing", `${settings.paragraphSpacing[0] / 100}em`);
        }
        
        // Apply font family
        if (settings.fontFamily === "dyslexic") {
          root.style.setProperty("--font-sans", "'Comic Sans MS', 'Comic Sans', cursive, sans-serif");
        } else if (settings.fontFamily === "arial") {
          root.style.setProperty("--font-sans", "Arial, sans-serif");
        }
        
        // Apply color overlay
        if (settings.colorOverlay) {
          root.setAttribute("data-color-overlay", settings.colorOverlay);
        }
      } catch (e) {
        console.error("Failed to load dyslexia settings", e);
      }
    }
    
    // Check onboarding after theme is loaded
    const timer = setTimeout(() => {
      setIsLoading(false);
      
      // Check localStorage for onboarding completion
      const onboardingComplete = localStorage.getItem("coda-onboarding-complete");
      const storedUserName = localStorage.getItem("coda-user-name");
      
      if (!onboardingComplete) {
        setShowOnboarding(true);
      } else if (storedUserName) {
        setUserName(storedUserName);
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  const handleOnboardingComplete = (data: OnboardingData) => {
    // Store onboarding data
    localStorage.setItem("coda-onboarding-complete", "true");
    localStorage.setItem("coda-user-name", data.name);
    localStorage.setItem("coda-communication-methods", JSON.stringify(data.communicationMethods));
    localStorage.setItem("coda-challenges", JSON.stringify(data.challenges));
    
    setUserName(data.name);
    setShowOnboarding(false);
    
    // Welcome toast
    toast.success(`Welcome to Coda, ${data.name}! 👋`, {
      description: "We're here to support your independence.",
    });
  };

  const navItems: NavItem[] = [
    { id: "aware", icon: Radar, label: "Aware" },
    { id: "talk", icon: MessageCircle, label: "Talk" },
    { id: "connect", icon: Users, label: "Connect" },
    { id: "study", icon: BookOpen, label: "Study" },
    { id: "alerts", icon: Bell, label: "Alerts" },
  ];

  const getActiveIndex = () => {
    return navItems.findIndex(item => item.id === activeView);
  };

  const renderView = () => {
    if (activeView === "settings") {
      return <SettingsView onClose={() => setActiveView("aware")} userName={userName} />;
    }
    return (
      <AwareScreen 
        userName={userName} 
        onOpenSettings={() => setActiveView("settings")}
        onViewChange={(view) => setCurrentSubView(view)}
      />
    );
  };

  // Determine if settings button should show based on the current sub-view
  const shouldShowSettings = activeView !== "settings" && (currentSubView === "aware" || currentSubView === "alerts");

  // Show loading screen
  if (isLoading) {
    return <WaveLoader />;
  }

  // Show onboarding flow
  if (showOnboarding) {
    return <OnboardingFlow onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className="h-full flex flex-col bg-[#FFFBF5] relative">
      {/* Offline Indicator */}
      <OfflineIndicator />

      {/* Settings Button - Only on Aware and Alerts pages */}
      <AnimatePresence>
        {shouldShowSettings && (
          <motion.button
            key="settings-button"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.2 }}
            onClick={() => setActiveView("settings")}
            className="absolute top-2 right-6 z-50 w-10 h-10 rounded-xl bg-white/80 backdrop-blur-xl border border-white/80 shadow-lg flex items-center justify-center hover:bg-white/90 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-[#2A0098] focus:ring-offset-2 focus:ring-offset-[#FFFBF5] transition-all active:scale-95"
            aria-label="Open settings"
          >
            <Settings className="w-5 h-5 text-[#2A0098]" strokeWidth={2} aria-hidden="true" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <div className="flex-1 overflow-hidden">
        {renderView()}
      </div>

      {/* Toast Notifications */}
      <Toaster 
        position="top-center"
        toastOptions={{
          style: {
            background: 'rgba(255, 255, 255, 0.95)',
            backdropFilter: 'blur(20px)',
            border: '1px solid rgba(255, 255, 255, 0.8)',
            borderRadius: '16px',
            color: '#2A0098',
            fontFamily: 'Inter, sans-serif',
          },
        }}
      />
    </div>
  );
}