import { User } from "lucide-react";

export function DashboardHeader() {
  return (
    <div className="flex items-center justify-between px-6 pt-6 pb-8">
      <h1 className="text-3xl text-[#2A0098]">
        Hello, <span className="text-[#6B5CAC]">Chen</span>
      </h1>
      <button className="w-11 h-11 rounded-full bg-gradient-to-br from-[#6B5CAC] to-[#8B7CAC] flex items-center justify-center hover:opacity-90 transition-opacity shadow-md">
        <User className="w-5 h-5 text-white" strokeWidth={2} />
      </button>
    </div>
  );
}
