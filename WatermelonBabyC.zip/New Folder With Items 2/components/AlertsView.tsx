"use client";

import { motion } from "motion/react";
import { Bell, Plus, Smartphone, DoorOpen, Siren, UserCheck, Volume2, Trash2, ChevronDown } from "lucide-react";
import { Switch } from "./ui/switch";
import { useState } from "react";
import { toast } from "sonner@2.0.3";

interface Alert {
  id: string;
  name: string;
  icon: any;
  description: string;
  enabled: boolean;
  gradient: string;
  vibration: "light" | "medium" | "strong";
  flash: boolean;
}

export function AlertsView() {
  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: "1",
      name: "Fire Alarm",
      icon: Siren,
      description: "Emergency building evacuation",
      enabled: true,
      gradient: "from-[#FF85A2] to-[#FFB3C6]",
      vibration: "strong",
      flash: true,
    },
    {
      id: "2",
      name: "Door Knock",
      icon: DoorOpen,
      description: "Someone at your door",
      enabled: true,
      gradient: "from-[#6B5CAC] to-[#8B7BC8]",
      vibration: "medium",
      flash: false,
    },
    {
      id: "3",
      name: "Phone Call",
      icon: Smartphone,
      description: "Incoming phone call",
      enabled: true,
      gradient: "from-[#F59E0B] to-[#FBBF24]",
      vibration: "medium",
      flash: true,
    },
    {
      id: "4",
      name: "Name Called",
      icon: UserCheck,
      description: "AI detected your name",
      enabled: false,
      gradient: "from-[#10B981] to-[#34D399]",
      vibration: "light",
      flash: false,
    },
  ]);

  const toggleAlert = (id: string) => {
    setAlerts(alerts.map(alert => {
      if (alert.id === id) {
        const newEnabled = !alert.enabled;
        toast.success(newEnabled ? `${alert.name} alert enabled` : `${alert.name} alert disabled`);
        return { ...alert, enabled: newEnabled };
      }
      return alert;
    }));
  };

  const updateVibration = (id: string, level: "light" | "medium" | "strong") => {
    setAlerts(alerts.map(alert =>
      alert.id === id ? { ...alert, vibration: level } : alert
    ));
    toast.success(`Vibration set to ${level}`);
  };

  const toggleFlash = (id: string) => {
    setAlerts(alerts.map(alert => {
      if (alert.id === id) {
        const newFlash = !alert.flash;
        toast.success(newFlash ? "Screen flash enabled" : "Screen flash disabled");
        return { ...alert, flash: newFlash };
      }
      return alert;
    }));
  };

  const deleteAlert = (id: string) => {
    setAlerts(alerts.filter(alert => alert.id !== id));
  };

  const [selectedAlert, setSelectedAlert] = useState<string | null>(null);

  return (
    <div className="h-full overflow-y-auto bg-[#FFFBF5]">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <h1 className="text-[#2A0098]">Alerts</h1>
        <p className="text-[#6B5CAC]">Customise your visual and haptic notifications</p>
      </div>

      {/* Quick stats - glassmorphic */}
      <div className="px-6 mb-6">
        <div className="bg-white/50 backdrop-blur-xl rounded-3xl p-5 border border-white/60 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3" aria-live="polite" aria-atomic="true">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#10B981] to-[#34D399] flex items-center justify-center shadow-md" aria-hidden="true">
                <Bell className="w-6 h-6 text-white" strokeWidth={2} />
              </div>
              <div>
                <p className="text-[#2A0098]">
                  {alerts.filter(a => a.enabled).length} active alerts
                </p>
                <p className="text-[#6B5CAC] text-sm">Out of {alerts.length} total</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Alerts list */}
      <div className="px-6 pb-8">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-[#2A0098]">Your Alerts</h2>
          <button 
            className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#6B5CAC] to-[#8B7BC8] flex items-center justify-center shadow-lg hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-[#6B5CAC] focus:ring-offset-2 focus:ring-offset-[#FFFBF5] transition-all"
            aria-label="Add new alert"
          >
            <Plus className="w-5 h-5 text-white" strokeWidth={2.5} aria-hidden="true" />
          </button>
        </div>
        
        <div className="space-y-3" role="list">
          {alerts.map((alert, index) => {
            const Icon = alert.icon;
            const isExpanded = selectedAlert === alert.id;
            
            return (
              <div
                key={alert.id}
                role="listitem"
                className="bg-white/50 backdrop-blur-xl rounded-3xl border border-white/60 shadow-lg overflow-hidden"
              >
                {/* Alert header */}
                <div className="p-4">
                  <div className="flex items-center gap-3">
                    {/* Icon and info - clickable to expand */}
                    <button
                      className="flex items-center gap-3 flex-1 min-w-0 text-left hover:opacity-80 focus:outline-none focus:ring-2 focus:ring-[#6B5CAC] focus:ring-offset-2 focus:ring-offset-white/50 rounded-2xl p-2 -m-2 transition-opacity"
                      onClick={() => setSelectedAlert(isExpanded ? null : alert.id)}
                      aria-label={`${alert.name}: ${alert.description}. ${alert.enabled ? 'Enabled' : 'Disabled'}. Click to ${isExpanded ? 'collapse' : 'expand'} settings`}
                      aria-expanded={isExpanded}
                    >
                      <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${alert.gradient} flex items-center justify-center flex-shrink-0 shadow-md`} aria-hidden="true">
                        <Icon className="w-6 h-6 text-white" strokeWidth={2} />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="text-[#2A0098] mb-0.5 not-italic">{alert.name}</h3>
                        <p className="text-[#6B5CAC] text-sm">{alert.description}</p>
                      </div>

                      <ChevronDown 
                        className={`w-5 h-5 text-[#6B5CAC] transition-transform flex-shrink-0 ${isExpanded ? 'rotate-180' : ''}`}
                        aria-hidden="true"
                      />
                    </button>
                    
                    {/* Toggle switch */}
                    <div className="flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                      <Switch
                        checked={alert.enabled}
                        onCheckedChange={() => toggleAlert(alert.id)}
                        aria-label={`${alert.enabled ? 'Disable' : 'Enable'} ${alert.name} alert`}
                      />
                    </div>
                  </div>
                </div>

                {/* Expanded details */}
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div className="px-4 pb-4 pt-2 border-t border-[#2A0098]/10 space-y-4">
                      {/* Vibration strength */}
                      <div>
                        <label className="text-[#2A0098] font-medium text-sm mb-3 block" id={`vibration-label-${alert.id}`}>
                          Vibration strength
                        </label>
                        <div 
                          className="space-y-2" 
                          role="radiogroup" 
                          aria-labelledby={`vibration-label-${alert.id}`}
                        >
                          {(["light", "medium", "strong"] as const).map((level) => {
                            const isSelected = alert.vibration === level;
                            return (
                              <button
                                key={level}
                                type="button"
                                onClick={() => updateVibration(alert.id, level)}
                                className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all ${
                                  isSelected
                                    ? `bg-gradient-to-r ${alert.gradient} text-white shadow-md`
                                    : "bg-white/70 text-[#2A0098] backdrop-blur-sm border-2 border-white/60 hover:border-[#6B5CAC]/30 hover:bg-white/90"
                                } focus:outline-none focus:ring-2 focus:ring-[#6B5CAC] focus:ring-offset-2 focus:ring-offset-white/50`}
                                role="radio"
                                aria-checked={isSelected}
                                aria-label={`Set vibration to ${level}`}
                              >
                                <div className="flex items-center gap-3">
                                  {/* Radio indicator */}
                                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                                    isSelected 
                                      ? 'border-white bg-white' 
                                      : 'border-[#6B5CAC]'
                                  }`}>
                                    {isSelected && (
                                      <div className={`w-2.5 h-2.5 rounded-full bg-gradient-to-r ${alert.gradient}`}></div>
                                    )}
                                  </div>
                                  
                                  {/* Label */}
                                  <span className="font-medium">
                                    {level.charAt(0).toUpperCase() + level.slice(1)}
                                  </span>
                                </div>
                                
                                {/* Visual indicator bars */}
                                <div className="flex items-center gap-1" aria-hidden="true">
                                  <div className={`w-1 rounded-full transition-all ${
                                    isSelected ? 'bg-white h-3' : 'bg-[#6B5CAC]/40 h-2'
                                  }`}></div>
                                  <div className={`w-1 rounded-full transition-all ${
                                    level !== 'light' 
                                      ? (isSelected ? 'bg-white h-4' : 'bg-[#6B5CAC]/40 h-3')
                                      : (isSelected ? 'bg-white/40 h-2' : 'bg-[#6B5CAC]/20 h-2')
                                  }`}></div>
                                  <div className={`w-1 rounded-full transition-all ${
                                    level === 'strong'
                                      ? (isSelected ? 'bg-white h-5' : 'bg-[#6B5CAC]/40 h-4')
                                      : (isSelected ? 'bg-white/40 h-2' : 'bg-[#6B5CAC]/20 h-2')
                                  }`}></div>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Flash toggle */}
                      <div className="flex items-center justify-between bg-white/70 backdrop-blur-sm rounded-2xl p-3 border border-white/60">
                        <div>
                          <p className="text-[#2A0098] text-sm font-medium">Screen flash</p>
                          <p className="text-[#6B5CAC] text-xs">Flash screen when alert triggers</p>
                        </div>
                        <Switch
                          checked={alert.flash}
                          onCheckedChange={() => toggleFlash(alert.id)}
                          aria-label={`${alert.flash ? 'Disable' : 'Enable'} screen flash for ${alert.name}`}
                        />
                      </div>

                      {/* Delete button */}
                      <button 
                        onClick={() => deleteAlert(alert.id)}
                        className="w-full py-3 rounded-2xl bg-[#FF85A2]/20 text-[#FF85A2] text-sm flex items-center justify-center gap-2 border border-[#FF85A2]/30 hover:bg-[#FF85A2]/30 focus:outline-none focus:ring-2 focus:ring-[#FF85A2] focus:ring-offset-2 focus:ring-offset-white/50 transition-all"
                        aria-label={`Delete ${alert.name} alert`}
                      >
                        <Trash2 className="w-4 h-4" aria-hidden="true" />
                        Delete Alert
                      </button>
                    </div>
                  </motion.div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
