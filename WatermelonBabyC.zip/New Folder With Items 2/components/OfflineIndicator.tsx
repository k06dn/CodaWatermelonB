import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { WifiOff, Wifi } from "lucide-react";

export function OfflineIndicator() {
  const [isOnline, setIsOnline] = useState(true);
  const [showReconnected, setShowReconnected] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowReconnected(true);
      setTimeout(() => setShowReconnected(false), 3000);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowReconnected(false);
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  return (
    <AnimatePresence>
      {(!isOnline || showReconnected) && (
        <motion.div
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -100, opacity: 0 }}
          transition={{ type: "spring", damping: 20 }}
          className={`fixed top-2 left-1/2 -translate-x-1/2 z-[100] px-4 py-2.5 rounded-xl backdrop-blur-xl border shadow-lg flex items-center gap-2 ${
            isOnline
              ? "bg-[#10B981]/90 border-[#10B981]/50 text-white"
              : "bg-red-500/90 border-red-400/50 text-white"
          }`}
          role="status"
          aria-live="polite"
        >
          {isOnline ? (
            <>
              <Wifi className="w-4 h-4" strokeWidth={2} aria-hidden="true" />
              <span className="text-sm leading-none">Back online</span>
            </>
          ) : (
            <>
              <WifiOff className="w-4 h-4" strokeWidth={2} aria-hidden="true" />
              <span className="text-sm leading-none">No internet connection</span>
            </>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
