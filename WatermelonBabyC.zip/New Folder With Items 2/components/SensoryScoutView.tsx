"use client";

import { motion } from "motion/react";
import { Map, BookOpen } from "lucide-react";
import { useState } from "react";
import { SensoryScoutRoom } from "./SensoryScoutRoom";

interface Resource {
  id: string;
  title: string;
  category: string;
  icon: any;
  gradient: string;
}

export function SensoryScoutView() {
  const [showSensoryScout, setShowSensoryScout] = useState(true);

  const resources: Resource[] = [
    {
      id: "1",
      title: "BSL Interpretation Guide",
      category: "Guide",
      icon: BookOpen,
      gradient: "from-[#6B5CAC] to-[#8B7BC8]",
    },
    {
      id: "2",
      title: "Campus Accessibility Map",
      category: "Resource",
      icon: Map,
      gradient: "from-[#10B981] to-[#34D399]",
    },
  ];

  if (showSensoryScout) {
    return (
      <div className="h-full">
        <SensoryScoutRoom onBack={() => setShowSensoryScout(false)} />
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto bg-[#FFFBF5]">
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <h1 className="text-[#10B981]">Sensory Scout</h1>
        <p className="text-[#6B5CAC]">
          Find accessible spaces with community ratings
        </p>
      </div>

      {/* Main Sensory Scout CTA */}
      <div className="px-6 mb-6">
        <motion.button
          onClick={() => setShowSensoryScout(true)}
          className="w-full bg-gradient-to-br from-[#10B981]/20 to-[#34D399]/20 backdrop-blur-xl rounded-3xl p-6 border border-[#10B981]/30 shadow-lg hover:bg-[#10B981]/30 focus:outline-none focus:ring-2 focus:ring-[#6B5CAC] focus:ring-offset-2 focus:ring-offset-[#FFFBF5] transition-all"
          whileTap={{ scale: 0.98 }}
          aria-label="Open Sensory Scout room reviews"
        >
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#10B981] to-[#34D399] flex items-center justify-center shadow-md" aria-hidden="true">
              <Map className="w-8 h-8 text-white" strokeWidth={2} />
            </div>
            <div className="flex-1 text-left">
              <h2 className="text-[#2A0098] mb-2">Browse Room Reviews</h2>
              <p className="text-[#6B5CAC] text-sm">
                Community-rated accessibility for lecture halls, seminar rooms, and study spaces
              </p>
            </div>
          </div>
        </motion.button>
      </div>

      {/* Quick Resources Section */}
      <div className="px-6 mb-6">
        <h2 className="text-[#2A0098] mb-3">Quick Resources</h2>
        <div className="grid grid-cols-2 gap-3">
          {resources.map((resource) => {
            const Icon = resource.icon;
            return (
              <motion.button
                key={resource.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="bg-white/50 backdrop-blur-xl rounded-2xl p-4 border border-white/60 shadow-lg hover:bg-white/70 focus:outline-none focus:ring-2 focus:ring-[#6B5CAC] focus:ring-offset-2 focus:ring-offset-[#FFFBF5] transition-all text-left"
                aria-label={`Open ${resource.title}`}
              >
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${resource.gradient} flex items-center justify-center mb-3 shadow-md`} aria-hidden="true">
                  <Icon className="w-5 h-5 text-white" strokeWidth={2} />
                </div>
                <h4 className="text-[#2A0098] text-sm mb-1">{resource.title}</h4>
                <p className="text-[#6B5CAC] text-xs">{resource.category}</p>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}