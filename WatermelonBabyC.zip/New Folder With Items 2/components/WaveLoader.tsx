import { motion } from "motion/react";

export function WaveLoader() {
  return (
    <div className="h-full w-full flex flex-col items-center justify-center bg-gradient-to-b from-[#FFFBF5] to-[#FFE5F0] px-6">
      {/* Logo/Title */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="mb-16 text-center"
      >
        <h1 className="text-[#2A0098] mb-2">Coda</h1>
        <p className="text-[#6B5CAC]">Your independence companion</p>
      </motion.div>

      {/* Animated Waves */}
      <div className="relative w-full max-w-[200px] h-24 flex items-end justify-center gap-2">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="w-3 bg-gradient-to-t from-[#FF85A2] to-[#FFB3C6] rounded-full"
            initial={{ height: "20%" }}
            animate={{
              height: ["20%", "100%", "20%"],
            }}
            transition={{
              duration: 1.2,
              repeat: Infinity,
              ease: "easeInOut",
              delay: i * 0.15,
            }}
            aria-hidden="true"
          />
        ))}
      </div>

      {/* Loading Text */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="text-[#6B5CAC] mt-12 text-sm"
        role="status"
        aria-live="polite"
      >
        Loading your experience...
      </motion.p>
    </div>
  );
}
