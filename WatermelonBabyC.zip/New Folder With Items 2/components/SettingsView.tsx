import { useState, useEffect } from "react";
import { ArrowLeft, Volume2, Vibrate, Moon, Trash2, User, Bell as BellIcon, BookOpen, Type } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Switch } from "./ui/switch";
import { Slider } from "./ui/slider";
import { toast } from "sonner@2.0.3";

interface SettingsViewProps {
  onClose: () => void;
  userName?: string;
}

interface VoiceProfile {
  id: string;
  name: string;
  dateAdded: string;
}

export function SettingsView({ onClose, userName = "there" }: SettingsViewProps) {
  const [hapticIntensity, setHapticIntensity] = useState([75]);
  const [bslCaptions, setBslCaptions] = useState(true);
  const [quietHours, setQuietHours] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [voiceProfiles, setVoiceProfiles] = useState<VoiceProfile[]>([
    { id: "1", name: "Mum", dateAdded: "2 weeks ago" },
    { id: "2", name: "Prof. Martinez", dateAdded: "5 days ago" },
    { id: "3", name: "Emma (flatmate)", dateAdded: "Yesterday" },
  ]);

  // Dyslexia-friendly reading settings
  const [lineSpacing, setLineSpacing] = useState([150]); // 150% = 1.5
  const [letterSpacing, setLetterSpacing] = useState([0]); // 0-5px
  const [wordSpacing, setWordSpacing] = useState([0]); // 0-10px
  const [fontFamily, setFontFamily] = useState("inter");
  const [textSize, setTextSize] = useState([100]); // 100% = base
  const [colorOverlay, setColorOverlay] = useState("none");
  const [paragraphSpacing, setParagraphSpacing] = useState([100]); // 100% = normal
  const [colorTheme, setColorTheme] = useState("default"); // App color theme

  const handleDeleteProfile = (id: string, name: string) => {
    setVoiceProfiles(prev => prev.filter(p => p.id !== id));
    toast.success(`Deleted voice profile: ${name}`);
  };

  const handleHapticChange = (value: number[]) => {
    setHapticIntensity(value);
    // Simulate haptic feedback
    if (navigator.vibrate) {
      navigator.vibrate(value[0]);
    }
  };

  // Load dyslexia settings from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("coda-dyslexia-settings");
    if (saved) {
      const settings = JSON.parse(saved);
      setLineSpacing(settings.lineSpacing || [150]);
      setLetterSpacing(settings.letterSpacing || [0]);
      setWordSpacing(settings.wordSpacing || [0]);
      setFontFamily(settings.fontFamily || "inter");
      setTextSize(settings.textSize || [100]);
      setColorOverlay(settings.colorOverlay || "none");
      setParagraphSpacing(settings.paragraphSpacing || [100]);
      setColorTheme(settings.colorTheme || "default");
    }
  }, []);

  // Apply dyslexia settings to document root
  useEffect(() => {
    const settings = {
      lineSpacing,
      letterSpacing,
      wordSpacing,
      fontFamily,
      textSize,
      colorOverlay,
      paragraphSpacing,
      colorTheme,
    };
    localStorage.setItem("coda-dyslexia-settings", JSON.stringify(settings));

    // Apply CSS custom properties
    const root = document.documentElement;
    root.style.setProperty("--dyslexia-line-spacing", `${lineSpacing[0] / 100}`);
    root.style.setProperty("--dyslexia-letter-spacing", `${letterSpacing[0] / 10}px`);
    root.style.setProperty("--dyslexia-word-spacing", `${wordSpacing[0] / 10}px`);
    root.style.setProperty("--dyslexia-text-size", `${textSize[0] / 100}`);
    root.style.setProperty("--dyslexia-paragraph-spacing", `${paragraphSpacing[0] / 100}em`);
    
    // Apply font family
    if (fontFamily === "dyslexic") {
      root.style.setProperty("--font-sans", "'Comic Sans MS', 'Comic Sans', cursive, sans-serif");
    } else if (fontFamily === "arial") {
      root.style.setProperty("--font-sans", "Arial, sans-serif");
    } else {
      root.style.setProperty("--font-sans", "'Inter', sans-serif");
    }

    // Apply color overlay
    root.setAttribute("data-color-overlay", colorOverlay);
    
    // Apply color theme
    root.setAttribute("data-color-theme", colorTheme);
  }, [lineSpacing, letterSpacing, wordSpacing, fontFamily, textSize, colorOverlay, paragraphSpacing, colorTheme]);

  const resetDyslexiaSettings = () => {
    setLineSpacing([150]);
    setLetterSpacing([0]);
    setWordSpacing([0]);
    setFontFamily("inter");
    setTextSize([100]);
    setColorOverlay("none");
    setParagraphSpacing([100]);
    setColorTheme("default");
    toast.success("Reading preferences reset to defaults");
  };

  return (
    <div className="h-full flex flex-col bg-[#FFFBF5]">
      {/* Header */}
      <div className="px-6 py-5 bg-white/60 backdrop-blur-xl border-b border-white/80">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-xl bg-white/80 backdrop-blur-sm flex items-center justify-center hover:bg-white/90 focus:outline-none focus:ring-2 focus:ring-[#2A0098] transition-all"
            aria-label="Go back"
          >
            <ArrowLeft className="w-5 h-5 text-[#2A0098]" strokeWidth={2} aria-hidden="true" />
          </button>
          <div className="flex-1">
            <h1 className="text-[#2A0098]">Settings</h1>
            <p className="text-[#6B5CAC] text-sm">Customise your Coda experience</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
        {/* Reading Preferences (Dyslexia-Friendly) Section */}
        <div className="bg-white/60 backdrop-blur-xl rounded-3xl border border-white/80 shadow-lg p-6 space-y-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6B5CAC] to-[#8B7BC8] flex items-center justify-center" aria-hidden="true">
              <BookOpen className="w-5 h-5 text-white" strokeWidth={2} aria-hidden="true" />
            </div>
            <div className="flex-1">
              <h2 className="text-[#2A0098]">Reading Preferences</h2>
              <p className="text-[#6B5CAC] text-xs mt-0.5">Dyslexia-friendly options</p>
            </div>
          </div>

          {/* Line Spacing */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label htmlFor="line-spacing-slider" className="text-[#2A0098] text-sm">
                Line Spacing
              </label>
              <span className="text-[#6B5CAC] text-sm">{(lineSpacing[0] / 100).toFixed(1)}x</span>
            </div>
            <Slider
              id="line-spacing-slider"
              value={lineSpacing}
              onValueChange={setLineSpacing}
              min={120}
              max={250}
              step={10}
              className="w-full"
              aria-label="Adjust line spacing"
            />
          </div>

          {/* Letter Spacing */}
          <div className="space-y-3 border-t border-white/50 pt-5">
            <div className="flex items-center justify-between">
              <label htmlFor="letter-spacing-slider" className="text-[#2A0098] text-sm">
                Letter Spacing
              </label>
              <span className="text-[#6B5CAC] text-sm">{letterSpacing[0] === 0 ? "Normal" : `+${(letterSpacing[0] / 10).toFixed(1)}px`}</span>
            </div>
            <Slider
              id="letter-spacing-slider"
              value={letterSpacing}
              onValueChange={setLetterSpacing}
              min={0}
              max={30}
              step={5}
              className="w-full"
              aria-label="Adjust letter spacing"
            />
          </div>

          {/* Word Spacing */}
          <div className="space-y-3 border-t border-white/50 pt-5">
            <div className="flex items-center justify-between">
              <label htmlFor="word-spacing-slider" className="text-[#2A0098] text-sm">
                Word Spacing
              </label>
              <span className="text-[#6B5CAC] text-sm">{wordSpacing[0] === 0 ? "Normal" : `+${(wordSpacing[0] / 10).toFixed(1)}px`}</span>
            </div>
            <Slider
              id="word-spacing-slider"
              value={wordSpacing}
              onValueChange={setWordSpacing}
              min={0}
              max={50}
              step={5}
              className="w-full"
              aria-label="Adjust word spacing"
            />
          </div>

          {/* Text Size */}
          <div className="space-y-3 border-t border-white/50 pt-5">
            <div className="flex items-center justify-between">
              <label htmlFor="text-size-slider" className="text-[#2A0098] text-sm">
                Text Size
              </label>
              <span className="text-[#6B5CAC] text-sm">{textSize[0]}%</span>
            </div>
            <Slider
              id="text-size-slider"
              value={textSize}
              onValueChange={setTextSize}
              min={80}
              max={150}
              step={10}
              className="w-full"
              aria-label="Adjust text size"
            />
          </div>

          {/* Paragraph Spacing */}
          <div className="space-y-3 border-t border-white/50 pt-5">
            <div className="flex items-center justify-between">
              <label htmlFor="paragraph-spacing-slider" className="text-[#2A0098] text-sm">
                Paragraph Spacing
              </label>
              <span className="text-[#6B5CAC] text-sm">{paragraphSpacing[0]}%</span>
            </div>
            <Slider
              id="paragraph-spacing-slider"
              value={paragraphSpacing}
              onValueChange={setParagraphSpacing}
              min={100}
              max={200}
              step={25}
              className="w-full"
              aria-label="Adjust paragraph spacing"
            />
          </div>

          {/* Font Family Selection */}
          <div className="space-y-3 border-t border-white/50 pt-5">
            <label className="text-[#2A0098] text-sm flex items-center gap-2">
              <Type className="w-4 h-4 text-[#6B5CAC]" strokeWidth={2} aria-hidden="true" />
              Font Style
            </label>
            <div className="grid grid-cols-1 gap-2">
              <button
                onClick={() => setFontFamily("inter")}
                className={`p-3 rounded-xl border transition-all text-left ${
                  fontFamily === "inter"
                    ? "bg-[#2A0098] text-white border-[#2A0098]"
                    : "bg-white/50 text-[#2A0098] border-white/60 hover:border-[#2A0098]/40"
                }`}
                aria-pressed={fontFamily === "inter"}
              >
                <span style={{ fontFamily: "'Inter', sans-serif" }}>Inter (Default)</span>
              </button>
              <button
                onClick={() => setFontFamily("dyslexic")}
                className={`p-3 rounded-xl border transition-all text-left ${
                  fontFamily === "dyslexic"
                    ? "bg-[#2A0098] text-white border-[#2A0098]"
                    : "bg-white/50 text-[#2A0098] border-white/60 hover:border-[#2A0098]/40"
                }`}
                aria-pressed={fontFamily === "dyslexic"}
              >
                <span style={{ fontFamily: "'Comic Sans MS', cursive" }}>Dyslexia-Friendly</span>
              </button>
              <button
                onClick={() => setFontFamily("arial")}
                className={`p-3 rounded-xl border transition-all text-left ${
                  fontFamily === "arial"
                    ? "bg-[#2A0098] text-white border-[#2A0098]"
                    : "bg-white/50 text-[#2A0098] border-white/60 hover:border-[#2A0098]/40"
                }`}
                aria-pressed={fontFamily === "arial"}
              >
                <span style={{ fontFamily: "Arial, sans-serif" }}>Arial (Simple)</span>
              </button>
            </div>
          </div>

          {/* Color Theme Selection */}
          <div className="space-y-3 border-t border-white/50 pt-5">
            <label className="text-[#2A0098] text-sm">
              Color Theme (interface colors & contrast)
            </label>
            <p className="text-[#6B5CAC] text-xs">
              Lower contrast themes reduce visual stress for dyslexia
            </p>
            <div className="grid grid-cols-1 gap-2">
              <button
                onClick={() => setColorTheme("default")}
                className={`p-3 rounded-xl border transition-all text-left flex items-center gap-3 ${
                  colorTheme === "default"
                    ? "bg-[#FFFBF5] border-[#2A0098] ring-2 ring-[#2A0098]"
                    : "bg-[#FFFBF5]/50 border-white/60 hover:border-[#2A0098]/40"
                }`}
                aria-pressed={colorTheme === "default"}
              >
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#FFFBF5] to-[#FFF8EF] border border-[#2A0098]/20"></div>
                <div>
                  <div className="text-sm" style={{ color: '#2A0098' }}>Warm Cream (Default)</div>
                  <div className="text-xs" style={{ color: '#6B5CAC' }}>Original Coda palette</div>
                </div>
              </button>
              <button
                onClick={() => setColorTheme("soft-beige")}
                className={`p-3 rounded-xl border transition-all text-left flex items-center gap-3 ${
                  colorTheme === "soft-beige"
                    ? "bg-[#F5F0E8] border-[#8B7355] ring-2 ring-[#8B7355]"
                    : "bg-[#F5F0E8]/50 border-white/60 hover:border-[#8B7355]/40"
                }`}
                aria-pressed={colorTheme === "soft-beige"}
              >
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#F5F0E8] to-[#EAE0D5] border border-[#8B7355]/20"></div>
                <div>
                  <div className="text-sm" style={{ color: '#5C4D3D' }}>Soft Beige</div>
                  <div className="text-xs" style={{ color: '#8B7355' }}>Low contrast, warm tones</div>
                </div>
              </button>
              <button
                onClick={() => setColorTheme("soft-blue")}
                className={`p-3 rounded-xl border transition-all text-left flex items-center gap-3 ${
                  colorTheme === "soft-blue"
                    ? "bg-[#E8F4F8] border-[#4A7C9C] ring-2 ring-[#4A7C9C]"
                    : "bg-[#E8F4F8]/50 border-white/60 hover:border-[#4A7C9C]/40"
                }`}
                aria-pressed={colorTheme === "soft-blue"}
              >
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#E8F4F8] to-[#D5E9F2] border border-[#4A7C9C]/20"></div>
                <div>
                  <div className="text-sm" style={{ color: '#2C5F7C' }}>Soft Blue</div>
                  <div className="text-xs" style={{ color: '#4A7C9C' }}>Calm, reduced glare</div>
                </div>
              </button>
              <button
                onClick={() => setColorTheme("soft-green")}
                className={`p-3 rounded-xl border transition-all text-left flex items-center gap-3 ${
                  colorTheme === "soft-green"
                    ? "bg-[#EDF7ED] border-[#5C8D5C] ring-2 ring-[#5C8D5C]"
                    : "bg-[#EDF7ED]/50 border-white/60 hover:border-[#5C8D5C]/40"
                }`}
                aria-pressed={colorTheme === "soft-green"}
              >
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#EDF7ED] to-[#DCEFD5] border border-[#5C8D5C]/20"></div>
                <div>
                  <div className="text-sm" style={{ color: '#3D6B3D' }}>Soft Green</div>
                  <div className="text-xs" style={{ color: '#5C8D5C' }}>Natural, easy on eyes</div>
                </div>
              </button>
              <button
                onClick={() => setColorTheme("soft-grey")}
                className={`p-3 rounded-xl border transition-all text-left flex items-center gap-3 ${
                  colorTheme === "soft-grey"
                    ? "bg-[#F0F0F0] border-[#666666] ring-2 ring-[#666666]"
                    : "bg-[#F0F0F0]/50 border-white/60 hover:border-[#666666]/40"
                }`}
                aria-pressed={colorTheme === "soft-grey"}
              >
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#F0F0F0] to-[#E5E5E5] border border-[#666666]/20"></div>
                <div>
                  <div className="text-sm" style={{ color: '#4A4A4A' }}>Soft Grey</div>
                  <div className="text-xs" style={{ color: '#666666' }}>Minimal contrast, neutral</div>
                </div>
              </button>
              <button
                onClick={() => setColorTheme("high-contrast")}
                className={`p-3 rounded-xl border transition-all text-left flex items-center gap-3 ${
                  colorTheme === "high-contrast"
                    ? "bg-white border-black ring-2 ring-black"
                    : "bg-white/50 border-white/60 hover:border-black/40"
                }`}
                aria-pressed={colorTheme === "high-contrast"}
              >
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-white to-[#F5F5F5] border-2 border-black/40"></div>
                <div>
                  <div className="text-sm" style={{ color: 'black' }}>High Contrast</div>
                  <div className="text-xs" style={{ color: '#666666' }}>Maximum visibility</div>
                </div>
              </button>
            </div>
          </div>

          {/* Color Overlay Selection */}
          <div className="space-y-3 border-t border-white/50 pt-5">
            <label className="text-[#2A0098] text-sm">
              Additional Color Tint (optional)
            </label>
            <p className="text-[#6B5CAC] text-xs">
              Adds a subtle overlay on top of your theme
            </p>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setColorOverlay("none")}
                className={`p-3 rounded-xl border transition-all ${
                  colorOverlay === "none"
                    ? "bg-[#2A0098] text-white border-[#2A0098]"
                    : "bg-white text-[#2A0098] border-white/60 hover:border-[#2A0098]/40"
                }`}
                aria-pressed={colorOverlay === "none"}
              >
                None
              </button>
              <button
                onClick={() => setColorOverlay("beige")}
                className={`p-3 rounded-xl border transition-all ${
                  colorOverlay === "beige"
                    ? "bg-[#F5DEB3] text-[#2A0098] border-[#F5DEB3] ring-2 ring-[#2A0098]"
                    : "bg-[#F5DEB3]/30 text-[#2A0098] border-[#F5DEB3] hover:border-[#F5DEB3]"
                }`}
                aria-pressed={colorOverlay === "beige"}
              >
                Beige
              </button>
              <button
                onClick={() => setColorOverlay("blue")}
                className={`p-3 rounded-xl border transition-all ${
                  colorOverlay === "blue"
                    ? "bg-[#ADD8E6] text-[#2A0098] border-[#ADD8E6] ring-2 ring-[#2A0098]"
                    : "bg-[#ADD8E6]/30 text-[#2A0098] border-[#ADD8E6] hover:border-[#ADD8E6]"
                }`}
                aria-pressed={colorOverlay === "blue"}
              >
                Blue
              </button>
              <button
                onClick={() => setColorOverlay("yellow")}
                className={`p-3 rounded-xl border transition-all ${
                  colorOverlay === "yellow"
                    ? "bg-[#FFFFE0] text-[#2A0098] border-[#FFFFE0] ring-2 ring-[#2A0098]"
                    : "bg-[#FFFFE0]/30 text-[#2A0098] border-[#FFFFE0] hover:border-[#FFFFE0]"
                }`}
                aria-pressed={colorOverlay === "yellow"}
              >
                Yellow
              </button>
              <button
                onClick={() => setColorOverlay("green")}
                className={`p-3 rounded-xl border transition-all ${
                  colorOverlay === "green"
                    ? "bg-[#D8FDCC] text-[#2A0098] border-[#D8FDCC] ring-2 ring-[#2A0098]"
                    : "bg-[#D8FDCC]/30 text-[#2A0098] border-[#D8FDCC] hover:border-[#D8FDCC]"
                }`}
                aria-pressed={colorOverlay === "green"}
              >
                Green
              </button>
              <button
                onClick={() => setColorOverlay("pink")}
                className={`p-3 rounded-xl border transition-all ${
                  colorOverlay === "pink"
                    ? "bg-[#FFB3C6] text-[#2A0098] border-[#FFB3C6] ring-2 ring-[#2A0098]"
                    : "bg-[#FFB3C6]/30 text-[#2A0098] border-[#FFB3C6] hover:border-[#FFB3C6]"
                }`}
                aria-pressed={colorOverlay === "pink"}
              >
                Pink
              </button>
            </div>
          </div>

          {/* Reset Button */}
          <div className="border-t border-white/50 pt-5">
            <button
              onClick={resetDyslexiaSettings}
              className="mx-auto block px-8 py-3 rounded-xl bg-[#6B5CAC]/10 hover:bg-[#6B5CAC]/20 text-[#6B5CAC] transition-colors focus:outline-none focus:ring-2 focus:ring-[#6B5CAC]"
            >
              Reset to defaults
            </button>
          </div>
        </div>

        {/* Accessibility Section */}
        <div className="bg-white/60 backdrop-blur-xl rounded-3xl border border-white/80 shadow-lg p-6 space-y-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FF85A2] to-[#FFB3C6] flex items-center justify-center" aria-hidden="true">
              <Volume2 className="w-5 h-5 text-white" strokeWidth={2} aria-hidden="true" />
            </div>
            <h2 className="text-[#2A0098]">Accessibility</h2>
          </div>

          {/* Haptic Intensity */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Vibrate className="w-4 h-4 text-[#6B5CAC]" strokeWidth={2} aria-hidden="true" />
                <label htmlFor="haptic-slider" className="text-[#2A0098] text-sm">
                  Haptic Intensity
                </label>
              </div>
              <span className="text-[#6B5CAC] text-sm">{hapticIntensity[0]}%</span>
            </div>
            <Slider
              id="haptic-slider"
              value={hapticIntensity}
              onValueChange={handleHapticChange}
              max={100}
              step={5}
              className="w-full"
              aria-label="Adjust haptic feedback intensity"
            />
          </div>

          {/* BSL Captions */}
          <div className="flex items-center justify-between py-3 border-t border-white/50">
            <div>
              <p className="text-[#2A0098] text-sm">BSL Video Captions</p>
              <p className="text-[#6B5CAC] text-xs mt-0.5">Show subtitles on BSL content</p>
            </div>
            <Switch
              checked={bslCaptions}
              onCheckedChange={(checked) => {
                setBslCaptions(checked);
                toast.success(checked ? "BSL captions enabled" : "BSL captions disabled");
              }}
              aria-label="Toggle BSL video captions"
            />
          </div>

          {/* Quiet Hours */}
          <div className="flex items-center justify-between py-3 border-t border-white/50">
            <div>
              <p className="text-[#2A0098] text-sm">Quiet Hours</p>
              <p className="text-[#6B5CAC] text-xs mt-0.5">Mute non-urgent alerts (10pm-8am)</p>
            </div>
            <Switch
              checked={quietHours}
              onCheckedChange={(checked) => {
                setQuietHours(checked);
                toast.success(checked ? "Quiet hours enabled" : "Quiet hours disabled");
              }}
              aria-label="Toggle quiet hours for alerts"
            />
          </div>

          {/* Dark Mode */}
          <div className="flex items-center justify-between py-3 border-t border-white/50">
            <div className="flex items-center gap-2">
              <Moon className="w-4 h-4 text-[#6B5CAC]" strokeWidth={2} aria-hidden="true" />
              <div>
                <p className="text-[#2A0098] text-sm">Dark Mode</p>
                <p className="text-[#6B5CAC] text-xs mt-0.5">Coming soon</p>
              </div>
            </div>
            <Switch
              checked={darkMode}
              onCheckedChange={setDarkMode}
              disabled
              aria-label="Toggle dark mode (coming soon)"
            />
          </div>
        </div>

        {/* Voice Profiles Section */}
        <div className="bg-white/60 backdrop-blur-xl rounded-3xl border border-white/80 shadow-lg p-6 space-y-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#6B5CAC] to-[#8B7BC8] flex items-center justify-center" aria-hidden="true">
              <User className="w-5 h-5 text-white" strokeWidth={2} aria-hidden="true" />
            </div>
            <div className="flex-1">
              <h2 className="text-[#2A0098]">Saved Voice Profiles</h2>
              <p className="text-[#6B5CAC] text-xs mt-0.5">{voiceProfiles.length} profile{voiceProfiles.length !== 1 ? 's' : ''} saved</p>
            </div>
          </div>

          {/* Voice Profiles List */}
          <div className="space-y-2">
            <AnimatePresence mode="popLayout">
              {voiceProfiles.map((profile) => (
                <motion.div
                  key={profile.id}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="flex items-center justify-between p-3 rounded-xl bg-white/50 border border-white/60"
                >
                  <div>
                    <p className="text-[#2A0098] text-sm">{profile.name}</p>
                    <p className="text-[#6B5CAC] text-xs">Added {profile.dateAdded}</p>
                  </div>
                  <button
                    onClick={() => handleDeleteProfile(profile.id, profile.name)}
                    className="w-8 h-8 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-red-400 transition-colors"
                    aria-label={`Delete voice profile for ${profile.name}`}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" strokeWidth={2} aria-hidden="true" />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>

            {voiceProfiles.length === 0 && (
              <div className="text-center py-8">
                <p className="text-[#6B5CAC] text-sm">No voice profiles yet</p>
                <p className="text-[#6B5CAC] text-xs mt-1">Add profiles in the Talk section</p>
              </div>
            )}
          </div>
        </div>

        {/* Notifications Section */}
        <div className="bg-white/60 backdrop-blur-xl rounded-3xl border border-white/80 shadow-lg p-6 space-y-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#D8FDCC] to-[#A8E6CF] flex items-center justify-center" aria-hidden="true">
              <BellIcon className="w-5 h-5 text-[#2A0098]" strokeWidth={2} aria-hidden="true" />
            </div>
            <h2 className="text-[#2A0098]">Notifications</h2>
          </div>

          <div className="text-center py-6">
            <p className="text-[#6B5CAC] text-sm">Customise notification preferences</p>
            <p className="text-[#6B5CAC] text-xs mt-1">Manage in the Alerts section</p>
          </div>
        </div>

        {/* About Section */}
        <div className="bg-white/60 backdrop-blur-xl rounded-3xl border border-white/80 shadow-lg p-6 text-center">
          <p className="text-[#2A0098] text-sm">Coda v1.0.0</p>
          <p className="text-[#6B5CAC] text-xs mt-1">
            Built for Deaf students to thrive independently
          </p>
          <p className="text-[#6B5CAC] text-xs mt-3">
            Made with care in the UK 🇬🇧
          </p>
        </div>

        {/* Reset Onboarding (for testing) */}
        <div className="bg-white/50 backdrop-blur-xl rounded-2xl p-4 border border-white/60">
          <button
            onClick={() => {
              localStorage.removeItem("coda-onboarding-complete");
              toast.success("Onboarding reset - refresh page to see it again");
            }}
            className="w-full py-3 rounded-xl bg-[#6B5CAC]/10 hover:bg-[#6B5CAC]/20 text-[#6B5CAC] transition-colors focus:outline-none focus:ring-2 focus:ring-[#6B5CAC] flex items-center justify-center"
          >
            Reset onboarding
          </button>
        </div>
      </div>
    </div>
  );
}
