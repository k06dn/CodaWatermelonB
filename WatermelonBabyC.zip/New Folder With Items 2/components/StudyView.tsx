"use client";

import { useState } from "react";
import { motion } from "motion/react";
import { Timer, Rocket, Users } from "lucide-react";
import { HapticPomodoro } from "./HapticPomodoro";
import { LaunchpadView } from "./LaunchpadView";
import { CommunityTab } from "./CommunityTab";

type StudyTab = "pomodoro" | "launchpad" | "community";

interface StudyViewProps {
  userName?: string;
}

export function StudyView({ userName = "there" }: StudyViewProps) {
  const [activeTab, setActiveTab] = useState<StudyTab>("pomodoro");

  const tabs = [
    {
      id: "pomodoro" as StudyTab,
      label: "Haptic Pomodoro",
      icon: Timer,
      description: "Silent study timer",
    },
    {
      id: "launchpad" as StudyTab,
      label: "Launchpad",
      icon: Rocket,
      description: "Pre-lecture prep",
    },
    {
      id: "community" as StudyTab,
      label: "Community",
      icon: Users,
      description: "Events & groups",
    },
  ];

  return (
    <div className="h-full flex flex-col bg-[#FFFBF5]">
      {/* Header - glassmorphic */}
      <div className="px-6 pt-6 pb-4 bg-white/60 backdrop-blur-xl border-b border-[#2A0098]/10">
        <div className="mb-4">
          <h1 className="text-[#2A0098]">Study</h1>
          <p className="text-[#6B5CAC]">Tools for independent learning</p>
        </div>

        {/* Tab Navigation */}
        <div 
          className="flex gap-2 bg-white/40 backdrop-blur-sm p-1 rounded-xl border border-white/60"
          role="tablist"
          aria-label="Study tools"
        >
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            // Different colors for each tab
            const getTabColors = () => {
              if (tab.id === "pomodoro") {
                return isActive 
                  ? "bg-gradient-to-br from-[#FF85A2] to-[#FFB3C6] text-white shadow-lg"
                  : "text-[#FF85A2] hover:bg-white/50";
              }
              if (tab.id === "launchpad") {
                return isActive
                  ? "bg-gradient-to-br from-[#2A0098] to-[#6B5CAC] text-white shadow-lg"
                  : "text-[#2A0098] hover:bg-white/50";
              }
              // community
              return isActive
                ? "bg-gradient-to-br from-[#10B981] to-[#34D399] text-white shadow-lg"
                : "text-[#10B981] hover:bg-white/50";
            };
            
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex flex-col items-center justify-center gap-1 px-2 py-2 rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-[#6B5CAC] focus:ring-offset-2 focus:ring-offset-[#FFFBF5] ${getTabColors()}`}
                role="tab"
                aria-selected={isActive}
                aria-controls={`${tab.id}-panel`}
                id={`${tab.id}-tab`}
                tabIndex={isActive ? 0 : -1}
              >
                <Icon 
                  className={`w-5 h-5 ${isActive ? "text-white" : ""}`} 
                  strokeWidth={2}
                  aria-hidden="true"
                />
                <span className="text-xs">
                  {tab.id === "pomodoro" ? "Timer" : tab.id === "launchpad" ? "Prep" : "Community"}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-hidden">
        {/* Pomodoro Panel */}
        <div
          role="tabpanel"
          id="pomodoro-panel"
          aria-labelledby="pomodoro-tab"
          hidden={activeTab !== "pomodoro"}
          className="h-full"
        >
          {activeTab === "pomodoro" && <HapticPomodoro />}
        </div>

        {/* Launchpad Panel */}
        <div
          role="tabpanel"
          id="launchpad-panel"
          aria-labelledby="launchpad-tab"
          hidden={activeTab !== "launchpad"}
          className="h-full"
        >
          {activeTab === "launchpad" && <LaunchpadView />}
        </div>

        {/* Community Panel */}
        <div
          role="tabpanel"
          id="community-panel"
          aria-labelledby="community-tab"
          hidden={activeTab !== "community"}
          className="h-full"
        >
          {activeTab === "community" && <CommunityTab />}
        </div>
      </div>
    </div>
  );
}