"use client";

import { motion } from "motion/react";
import { Users, Clock, MessageCircle, Heart, Calendar, MapPin, Filter } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner@2.0.3";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface Event {
  id: string;
  title: string;
  type: string;
  location: string;
  time: string;
  attendees: number;
  hasInterpreter: boolean;
  hasCaption: boolean;
  gradient: string;
}

interface StudyGroup {
  id: string;
  name: string;
  course: string;
  members: number;
  nextMeeting: string;
  gradient: string;
}

export function CommunityTab() {
  const [likedEvents, setLikedEvents] = useState<string[]>([]);
  const [eventFilter, setEventFilter] = useState<'all' | 'bsl' | 'captions'>('all');

  const toggleLike = (eventId: string) => {
    setLikedEvents(prev => 
      prev.includes(eventId) 
        ? prev.filter(id => id !== eventId)
        : [...prev, eventId]
    );
    
    const event = events.find(e => e.id === eventId);
    if (event && !likedEvents.includes(eventId)) {
      toast.success(`Saved ${event.title}`, {
        description: "You'll be notified before the event"
      });
    }
  };

  const events: Event[] = [
    {
      id: "1",
      title: "BSL Coffee Chat",
      type: "Social",
      location: "Student Union, Room 204",
      time: "Today, 3:00 PM",
      attendees: 12,
      hasInterpreter: true,
      hasCaption: false,
      gradient: "from-[#6B5CAC] to-[#8B7BC8]",
    },
    {
      id: "2",
      title: "Accessible Tech Workshop",
      type: "Workshop",
      location: "Engineering Building",
      time: "Tomorrow, 2:00 PM",
      attendees: 8,
      hasInterpreter: true,
      hasCaption: true,
      gradient: "from-[#FF85A2] to-[#FFB3C6]",
    },
    {
      id: "3",
      title: "Study Skills Session",
      type: "Academic",
      location: "Learning Centre",
      time: "Friday, 1:00 PM",
      attendees: 15,
      hasInterpreter: false,
      hasCaption: true,
      gradient: "from-[#10B981] to-[#34D399]",
    },
  ];

  const studyGroups: StudyGroup[] = [
    {
      id: "1",
      name: "Data Structures Study Group",
      course: "CS 301",
      members: 5,
      nextMeeting: "Wed, 4:00 PM",
      gradient: "from-[#F59E0B] to-[#FBBF24]",
    },
    {
      id: "2",
      name: "Organic Chemistry Review",
      course: "CHEM 210",
      members: 4,
      nextMeeting: "Thu, 6:00 PM",
      gradient: "from-[#10B981] to-[#34D399]",
    },
  ];

  const filteredEvents = events.filter(event => {
    if (eventFilter === 'bsl') return event.hasInterpreter;
    if (eventFilter === 'captions') return event.hasCaption;
    return true;
  });

  return (
    <div className="h-full overflow-y-auto bg-[#FFFBF5] px-6 py-4">
      {/* Campus Deaf and HOH Network - Image Header */}
      <div className="mb-6">
        <div className="relative h-40 rounded-3xl overflow-hidden shadow-lg">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1758272133542-b3107b947fc2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXZlcnNlJTIwZnJpZW5kcyUyMGNvbW11bml0eXxlbnwxfHx8fDE3NjAxMDc5NjR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Community members socializing together"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#2A0098]/80 via-[#2A0098]/20 to-transparent"></div>
          <div className="absolute bottom-4 left-4 right-4">
            <h2 className="text-white mb-1">Campus Deaf & HOH Network</h2>
            <p className="text-white/90 text-sm">124 students • Join the community</p>
          </div>
        </div>
      </div>

      {/* BSL Events & Meetups */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-[#2A0098]" style={{ fontWeight: 700 }}>
            Upcoming Events
          </h3>
          
          {/* Filter Pills */}
          <div className="flex gap-2">
            <button
              onClick={() => setEventFilter('all')}
              className={`px-3 py-1.5 rounded-full text-xs transition-all ${
                eventFilter === 'all'
                  ? 'bg-[#6B5CAC] text-white'
                  : 'bg-white/60 text-[#6B5CAC] border border-[#6B5CAC]/20'
              }`}
              style={{ fontWeight: 600 }}
            >
              All
            </button>
            <button
              onClick={() => setEventFilter('bsl')}
              className={`px-3 py-1.5 rounded-full text-xs transition-all ${
                eventFilter === 'bsl'
                  ? 'bg-[#6B5CAC] text-white'
                  : 'bg-white/60 text-[#6B5CAC] border border-[#6B5CAC]/20'
              }`}
              style={{ fontWeight: 600 }}
            >
              BSL
            </button>
            <button
              onClick={() => setEventFilter('captions')}
              className={`px-3 py-1.5 rounded-full text-xs transition-all ${
                eventFilter === 'captions'
                  ? 'bg-[#6B5CAC] text-white'
                  : 'bg-white/60 text-[#6B5CAC] border border-[#6B5CAC]/20'
              }`}
              style={{ fontWeight: 600 }}
            >
              Captions
            </button>
          </div>
        </div>

        <div className="space-y-3">
          {filteredEvents.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/60 backdrop-blur-xl rounded-2xl p-4 border border-white/80 shadow-sm"
            >
              <div className="flex gap-3">
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${event.gradient} flex items-center justify-center flex-shrink-0 shadow-md`}>
                  <Calendar className="w-6 h-6 text-white" strokeWidth={2} />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <h4 className="text-[#2A0098] mb-1" style={{ fontWeight: 600 }}>
                        {event.title}
                      </h4>
                      <span className="px-2 py-0.5 bg-[#6B5CAC]/10 rounded-full text-[#6B5CAC] text-xs" style={{ fontWeight: 600 }}>
                        {event.type}
                      </span>
                    </div>
                    <button
                      onClick={() => toggleLike(event.id)}
                      className="w-8 h-8 rounded-full bg-white/60 backdrop-blur-xl flex items-center justify-center hover:bg-white/80 transition-colors"
                      aria-label={likedEvents.includes(event.id) ? "Unsave event" : "Save event"}
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          likedEvents.includes(event.id)
                            ? 'fill-[#FF85A2] text-[#FF85A2]'
                            : 'text-[#6B5CAC]'
                        }`}
                        strokeWidth={2}
                      />
                    </button>
                  </div>

                  <div className="space-y-1 text-xs text-[#6B5CAC]">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3 h-3" />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3 h-3" />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Users className="w-3 h-3" />
                      <span>{event.attendees} attending</span>
                    </div>
                  </div>

                  {/* Accessibility Features */}
                  <div className="flex gap-2 mt-3">
                    {event.hasInterpreter && (
                      <span className="px-2 py-1 bg-[#10B981]/10 border border-[#10B981]/20 rounded-lg text-[#10B981] text-xs" style={{ fontWeight: 600 }}>
                        BSL Interpreter
                      </span>
                    )}
                    {event.hasCaption && (
                      <span className="px-2 py-1 bg-[#3B82F6]/10 border border-[#3B82F6]/20 rounded-lg text-[#3B82F6] text-xs" style={{ fontWeight: 600 }}>
                        Captions
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {filteredEvents.length === 0 && (
          <div className="text-center py-8">
            <p className="text-[#6B5CAC]">No events match this filter</p>
          </div>
        )}
      </div>

      {/* Study Groups */}
      <div className="mb-6">
        <h3 className="text-[#2A0098] mb-4" style={{ fontWeight: 700 }}>
          Study Groups
        </h3>
        <div className="space-y-3">
          {studyGroups.map((group, index) => (
            <motion.button
              key={group.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: (filteredEvents.length + index) * 0.1 }}
              className="w-full bg-white/60 backdrop-blur-xl rounded-2xl p-4 border border-white/80 shadow-sm hover:shadow-md hover:bg-white/70 focus:outline-none focus:ring-2 focus:ring-[#6B5CAC] focus:ring-offset-2 focus:ring-offset-[#FFFBF5] transition-all text-left"
              onClick={() => toast.success(`Opening ${group.name}`, {
                description: "Study group details would open here"
              })}
              aria-label={`View ${group.name} study group for ${group.course}. ${group.members} members. Next meeting ${group.nextMeeting}`}
            >
              <div className="flex gap-3">
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${group.gradient} flex items-center justify-center flex-shrink-0 shadow-md`}>
                  <MessageCircle className="w-6 h-6 text-white" strokeWidth={2} />
                </div>
                
                <div className="flex-1 min-w-0">
                  <h4 className="text-[#2A0098] mb-1.5" style={{ fontWeight: 600 }}>
                    {group.name}
                  </h4>
                  <div className="space-y-0.5 text-xs text-[#6B5CAC]">
                    <div className="flex items-center gap-1.5">
                      <span className="px-2 py-0.5 bg-[#6B5CAC]/10 border border-[#6B5CAC]/20 rounded-full" style={{ fontWeight: 600 }}>
                        {group.course}
                      </span>
                      <span>{group.members} members</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>Next: {group.nextMeeting}</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* CTA to Create/Join */}
      <div className="pb-6">
        <div className="bg-[#FF85A2]/10 backdrop-blur-xl rounded-2xl p-5 border border-[#FF85A2]/20">
          <h3 className="text-[#2A0098] mb-2" style={{ fontWeight: 700 }}>
            Start Your Own 🚀
          </h3>
          <p className="text-[#6B5CAC] text-sm mb-4">
            Create a new study group or event for the Deaf and HOH community
          </p>
          <button
            onClick={() => toast.success("Create Event/Group", {
              description: "Creation form would open here"
            })}
            className="w-full bg-gradient-to-r from-[#FF85A2] to-[#6B5CAC] text-white rounded-xl p-3 hover:shadow-lg transition-all"
            style={{ fontWeight: 700 }}
          >
            + Create Event or Study Group
          </button>
        </div>
      </div>
    </div>
  );
}