import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Users, Shield, Clock, Trash2, Share2, CheckCircle2, Circle } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface Participant {
  id: string;
  name: string;
  hasConsented: boolean;
  joinedAt: Date;
}

interface GroupConsentHostProps {
  onStartRecording: (participants: Participant[]) => void;
  onCancel: () => void;
  hostName: string;
}

export function GroupConsentHost({ onStartRecording, onCancel, hostName }: GroupConsentHostProps) {
  const [sessionId] = useState(() => Math.random().toString(36).substring(2, 9));
  const [participants, setParticipants] = useState<Participant[]>([
    { id: "host", name: hostName || "You", hasConsented: true, joinedAt: new Date() }
  ]);
  const [shareLink, setShareLink] = useState("");

  useEffect(() => {
    // Generate shareable link (for demo purposes - in production this would be a real URL)
    const link = `${window.location.origin}/join/${sessionId}`;
    setShareLink(link);
  }, [sessionId]);

  const allConsented = participants.length > 1 && participants.every(p => p.hasConsented);
  const waitingCount = participants.filter(p => !p.hasConsented).length;

  const handleStartRecording = () => {
    if (!allConsented) {
      toast.error("All participants must consent before starting");
      return;
    }
    onStartRecording(participants);
  };

  const handleRemoveParticipant = (id: string) => {
    if (id === "host") return;
    setParticipants(prev => prev.filter(p => p.id !== id));
    toast.success("Participant removed");
  };

  const handleCopyLink = async () => {
    try {
      // Try modern clipboard API first
      await navigator.clipboard.writeText(shareLink);
      toast.success("Link copied to clipboard!");
    } catch (err) {
      // Fallback for when clipboard API is blocked
      try {
        // Create temporary textarea
        const textarea = document.createElement('textarea');
        textarea.value = shareLink;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        toast.success("Link copied to clipboard!");
      } catch (fallbackErr) {
        // If both methods fail, show the link for manual copying
        toast.info("Copy this link manually", {
          description: shareLink,
          duration: 5000
        });
      }
    }
  };

  // Simulate participant joining (for demo - in production this would come from real-time updates)
  const simulateParticipantJoin = () => {
    const demoNames = ["Emma", "Tom", "Alex", "Sarah", "James"];
    const availableNames = demoNames.filter(name => !participants.some(p => p.name === name));
    if (availableNames.length === 0) return;

    const randomName = availableNames[Math.floor(Math.random() * availableNames.length)];
    const newParticipant: Participant = {
      id: Math.random().toString(36).substring(2, 9),
      name: randomName,
      hasConsented: Math.random() > 0.3, // 70% chance of auto-consent for demo
      joinedAt: new Date()
    };
    setParticipants(prev => [...prev, newParticipant]);
    toast.success(`${randomName} has joined!`);
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-[#FFFBF5] to-[#FFF8EF]">
      {/* Header */}
      <div className="px-6 pt-4 pb-3">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-[#EC4899] to-[#F472B6] mb-3">
            <Users className="w-8 h-8 text-white" strokeWidth={2} />
          </div>
          <h1 className="text-[#2A0098] mb-1">Start Group Conversation</h1>
          <p className="text-[#6B5CAC] text-sm">Privacy-first recording with group consent</p>
        </motion.div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 pb-6 space-y-5">
        {/* Privacy Information Card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/60 backdrop-blur-xl rounded-3xl border border-white/80 shadow-lg p-5 space-y-3"
        >
          <div className="flex items-center gap-2 mb-2">
            <Shield className="w-5 h-5 text-[#2A0098]" strokeWidth={2} />
            <h3 className="text-[#2A0098]">Before Recording</h3>
          </div>
          
          <div className="space-y-2.5">
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#6B5CAC] mt-0.5 flex-shrink-0" strokeWidth={2} />
              <p className="text-[#2A0098] text-sm">All participants must give explicit consent</p>
            </div>
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#6B5CAC] mt-0.5 flex-shrink-0" strokeWidth={2} />
              <p className="text-[#2A0098] text-sm">Transcription visible only to this group</p>
            </div>
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#6B5CAC] mt-0.5 flex-shrink-0" strokeWidth={2} />
              <p className="text-[#2A0098] text-sm">Data stored locally on your device</p>
            </div>
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#6B5CAC] mt-0.5 flex-shrink-0" strokeWidth={2} />
              <p className="text-[#2A0098] text-sm">Auto-deleted after 30 days</p>
            </div>
            <div className="flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#6B5CAC] mt-0.5 flex-shrink-0" strokeWidth={2} />
              <p className="text-[#2A0098] text-sm">Anyone can leave and withdraw consent anytime</p>
            </div>
          </div>
        </motion.div>

        {/* Share Session Card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/60 backdrop-blur-xl rounded-3xl border border-white/80 shadow-lg p-5"
        >
          <div className="flex items-center gap-2 mb-3">
            <Share2 className="w-5 h-5 text-[#2A0098]" strokeWidth={2} />
            <h3 className="text-[#2A0098]">Invite Participants</h3>
          </div>
          
          <div className="bg-white/50 rounded-xl p-4 mb-4 border border-white/60">
            <p className="text-[#6B5CAC] text-xs mb-3">Session Link</p>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <code className="flex-1 text-xs text-[#2A0098] bg-white/80 rounded-lg px-3 py-3 border border-white/60 overflow-x-auto break-all">
                {shareLink}
              </code>
              <button
                onClick={handleCopyLink}
                className="px-5 py-3 rounded-lg bg-gradient-to-br from-[#6B5CAC] to-[#8B7BC8] text-white hover:shadow-lg transition-all focus:outline-none focus:ring-2 focus:ring-[#6B5CAC] min-h-[44px] whitespace-nowrap"
                aria-label="Copy link"
              >
                Copy Link
              </button>
            </div>
          </div>

          {/* Demo button for adding participants */}
          <button
            onClick={simulateParticipantJoin}
            className="mx-auto block px-6 py-2.5 rounded-xl bg-[#6B5CAC]/10 hover:bg-[#6B5CAC]/20 text-[#6B5CAC] text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-[#6B5CAC] min-h-[44px]"
          >
            + Simulate Participant Join (Demo)
          </button>
        </motion.div>

        {/* Participants Waiting Room */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white/60 backdrop-blur-xl rounded-3xl border border-white/80 shadow-lg p-5"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-[#2A0098]" strokeWidth={2} />
              <h3 className="text-[#2A0098]">Participants</h3>
            </div>
            <div className="px-3 py-1 rounded-full bg-[#EC4899]/10 border border-[#EC4899]/20">
              <span className="text-[#EC4899] text-sm">{participants.length} joined</span>
            </div>
          </div>

          {waitingCount > 0 && (
            <div className="mb-4 p-3 rounded-xl bg-[#FF85A2]/10 border border-[#FF85A2]/20">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#FF85A2]" strokeWidth={2} />
                <p className="text-[#FF85A2] text-sm">
                  Waiting for {waitingCount} {waitingCount === 1 ? "person" : "people"} to consent
                </p>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <AnimatePresence mode="popLayout">
              {participants.map((participant) => (
                <motion.div
                  key={participant.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="flex items-center gap-3 p-3 rounded-xl bg-white/50 border border-white/60"
                >
                  <div className="flex-shrink-0">
                    {participant.hasConsented ? (
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#10b981] to-[#34d399] flex items-center justify-center">
                        <CheckCircle2 className="w-5 h-5 text-white" strokeWidth={2} />
                      </div>
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-[#6B5CAC]/20 flex items-center justify-center">
                        <Circle className="w-5 h-5 text-[#6B5CAC]" strokeWidth={2} />
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <p className="text-[#2A0098]">
                      {participant.name}
                      {participant.id === "host" && " (Host)"}
                    </p>
                    <p className="text-[#6B5CAC] text-xs">
                      {participant.hasConsented ? "✓ Consented" : "Waiting for consent..."}
                    </p>
                  </div>

                  {participant.id !== "host" && (
                    <button
                      onClick={() => handleRemoveParticipant(participant.id)}
                      className="p-2 rounded-lg hover:bg-white/80 text-[#6B5CAC] hover:text-[#FF85A2] transition-colors focus:outline-none focus:ring-2 focus:ring-[#FF85A2]"
                      aria-label={`Remove ${participant.name}`}
                    >
                      <Trash2 className="w-4 h-4" strokeWidth={2} />
                    </button>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>

      {/* Footer Actions */}
      <div className="px-6 pb-6 pt-4 border-t border-white/50 bg-white/40 backdrop-blur-xl">
        <div className="max-w-md mx-auto space-y-3">
          <button
            onClick={handleStartRecording}
            disabled={!allConsented}
            className={`w-full py-4 rounded-xl transition-all focus:outline-none focus:ring-2 focus:ring-[#EC4899] focus:ring-offset-2 focus:ring-offset-[#FFFBF5] min-h-[56px] flex items-center justify-center ${
              allConsented
                ? "bg-gradient-to-br from-[#EC4899] to-[#F472B6] text-white shadow-lg hover:shadow-xl"
                : "bg-[#6B5CAC]/20 text-[#6B5CAC]/50 cursor-not-allowed"
            }`}
          >
            {allConsented ? "🎙️ Start Recording" : `⏳ Waiting for ${waitingCount} consent${waitingCount !== 1 ? "s" : ""}`}
          </button>

          <button
            onClick={onCancel}
            className="w-full py-3 rounded-xl bg-white/60 hover:bg-white/80 text-[#6B5CAC] border border-white/80 transition-all focus:outline-none focus:ring-2 focus:ring-[#6B5CAC] min-h-[44px]"
          >
            Cancel Session
          </button>
        </div>
      </div>
    </div>
  );
}
